import os

import bcrypt
import mysql.connector
from flask import Flask, redirect, render_template, request, session, url_for
from mysql.connector import Error

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "mude-esta-chave-antes-de-publicar")


def obter_conexao():
    return mysql.connector.connect(
        host=os.environ.get("DB_HOST", "localhost"),
        user=os.environ.get("DB_USER", "root"),
        password=os.environ.get("DB_PASSWORD", ""),
        database=os.environ.get("DB_NAME", "conexaovett"),
        port=int(os.environ.get("DB_PORT", "3306")),
    )


def exigir_login():
    if "usuario_id" not in session:
        return redirect(url_for("login"))
    return None


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form.get("username", "").strip()
        senha = request.form.get("password", "")
        conexao = None
        try:
            conexao = obter_conexao()
            cursor = conexao.cursor(dictionary=True)
            cursor.execute("SELECT id, usuario, senha FROM usuarios WHERE usuario = %s", (usuario,))
            conta = cursor.fetchone()
            cursor.close()

            senha_valida = False
            if conta:
                try:
                    # Tenta validar como hash (bcrypt)
                    senha_valida = bcrypt.checkpw(senha.encode("utf-8"), conta["senha"].encode("utf-8"))
                except ValueError:
                    # Se não for hash, compara como texto normal
                    senha_valida = (senha == conta["senha"])

            if senha_valida:
                session.clear()
                session["usuario_id"] = conta["id"]
                session["usuario"] = conta["usuario"]
                return redirect(url_for("home"))

            return render_template("login.html", erro="Usuário ou senha inválidos.")
        except Error:
            app.logger.exception("Falha ao validar login")
            return render_template("login.html", erro="Não foi possível acessar o banco de dados.")
        finally:
            if conexao and conexao.is_connected():
                conexao.close()

    if "usuario_id" in session:
        return redirect(url_for("home"))
    return render_template("login.html")

@app.route("/inicio")
def home():
    bloqueio = exigir_login()
    if bloqueio:
        return bloqueio
    conexao = None
    try:
        conexao = obter_conexao()
        cursor = conexao.cursor(dictionary=True)
        cursor.execute("""
            SELECT p.nome AS nome_pet, p.nome_tutor, p.idade AS idade_pet,
                   c.motivo AS motivo_consulta
            FROM consultas c
            JOIN pets p ON p.id = c.pet_id
            ORDER BY c.data_consulta DESC, c.hora_consulta DESC
        """)
        consultas = cursor.fetchall()
        cursor.close()
        return render_template("inicio.html", consultas=consultas)
    except Error:
        app.logger.exception("Falha ao carregar consultas")
        return render_template("inicio.html", consultas=[], erro="Não foi possível carregar os registros.")
    finally:
        if conexao and conexao.is_connected():
            conexao.close()

    return render_template("inicio.html")

@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    bloqueio = exigir_login()
    if bloqueio:
        return bloqueio
    if request.method == "POST":
        nome_pet = request.form.get("nomePet", "").strip()
        especie = request.form.get("especie", "").strip()
        raca = request.form.get("raca", "").strip()
        nome_tutor = request.form.get("nomeTutor", "").strip()
        cpf_tutor = "".join(filter(str.isdigit, request.form.get("cpfTutor", "")))
        try:
            idade = int(request.form.get("idadePet", ""))
            if not nome_pet or not especie or not nome_tutor or len(cpf_tutor) != 11 or idade < 0:
                raise ValueError
            conexao = obter_conexao()
            cursor = conexao.cursor()
            cursor.execute("""INSERT INTO pets (nome, especie, raca, idade, nome_tutor, cpf_tutor)
                              VALUES (%s, %s, %s, %s, %s, %s)""",
                           (nome_pet, especie, raca, idade, nome_tutor, cpf_tutor))
            conexao.commit()
            cursor.close()
            conexao.close()
            return render_template("cadastro.html", sucesso="Pet cadastrado com sucesso.")
        except ValueError:
            return render_template("cadastro.html", erro="Confira os campos. Informe idade válida e CPF com 11 dígitos.")
        except Error:
            app.logger.exception("Falha ao cadastrar pet")
            return render_template("cadastro.html", erro="Não foi possível salvar o pet. Verifique os dados e o banco.")
    return render_template("cadastro.html")


@app.route("/consultas", methods=["GET", "POST"])
def consulta():
    bloqueio = exigir_login()
    if bloqueio:
        return bloqueio
    if request.method == "POST":
        tutor = request.form.get("nomeTutor", "").strip()
        nome_pet = request.form.get("nomePet", "").strip()
        cpf = "".join(filter(str.isdigit, request.form.get("cpfTutor", "")))
        data = request.form.get("dataConsulta", "")
        hora = request.form.get("horaConsulta", "")
        motivo = request.form.get("motivo", "").strip()
        conexao = None
        try:
            if len(cpf) != 11 or not all((tutor, nome_pet, data, hora, motivo)):
                raise ValueError
            conexao = obter_conexao()
            cursor = conexao.cursor(dictionary=True)
            cursor.execute("SELECT id FROM pets WHERE nome = %s AND nome_tutor = %s AND cpf_tutor = %s",
                           (nome_pet, tutor, cpf))
            pet = cursor.fetchone()
            if not pet:
                cursor.close()
                return render_template("consultas.html", erro="Pet não encontrado para esse tutor e CPF. Cadastre o pet primeiro.")
            cursor.execute("INSERT INTO consultas (pet_id, data_consulta, hora_consulta, motivo) VALUES (%s, %s, %s, %s)",
                           (pet["id"], data, hora, motivo))
            conexao.commit()
            cursor.close()
            return render_template("consultas.html", sucesso="Consulta agendada com sucesso.")
        except ValueError:
            return render_template("consultas.html", erro="Preencha todos os campos e informe um CPF com 11 dígitos.")
        except Error:
            app.logger.exception("Falha ao agendar consulta")
            return render_template("consultas.html", erro="Não foi possível agendar. Verifique o horário e tente novamente.")
        finally:
            if conexao and conexao.is_connected():
                conexao.close()
    return render_template("consultas.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
