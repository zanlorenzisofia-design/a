﻿CREATE DATABASE conexaovett
USE conexaovet;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100) NOT NULL,
    senha VARCHAR(255) NOT NULL
);

CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    especie VARCHAR(50) NOT NULL,
    raca VARCHAR(100) NOT NULL,
    idade INT NOT NULL,
    nome_tutor VARCHAR(100) NOT NULL,
    cpf_tutor CHAR(11) NOT NULL,
);

CREATE TABLE consultas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pet_id INT NOT NULL,
    data_consulta DATE NOT NULL,
    hora_consulta TIME NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    UNIQUE KEY uq_consulta_horario (data_consulta, hora_consulta)
);

INSERT INTO usuarios (id, usuario, senha) 
VALUES ('1', 'sofia', '1234');

